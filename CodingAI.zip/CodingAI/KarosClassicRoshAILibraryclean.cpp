#include <iostream>
//#include "KarosRoshAILibrarydebug.cpp"
#include "newKarosRoshDebugbaseclean.cpp"
int main(int argc, char *argv[])
{
	//for(;;) {
	system("antlr4-parse C.g4 prog -tokens -gui < box.c");
	printf("Welcome to the Karos Rosh AI system!");
    
     //This is the main code navigator
     //So at least no more spaghetti code!
	 //Should name it AIlibrary or another better functions!
             //So finally organising C code in some kind of decent way!
             //othernonsense();
             //NO nO can't take two files as arguments!
             //Or other AI system functions, like Scanner, Lexer, Automated reasoning and
             //NLP, Knowledgebase!
			 system("gen < parse.a > wileyfox");
			 system("parse < lex.a > parse.a");
			 system("lex < while.t > lex.a");
			 
			 //Mainsclutter should be called somewhere here when we care about it!
			 Mainsclutter();
}
