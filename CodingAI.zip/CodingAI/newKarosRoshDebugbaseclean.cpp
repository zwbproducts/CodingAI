#pragma warning(disable: 4786)
#include <stdio.h>
#include <iostream>
#include <memory>
#include <string>
#include <vector>
#include <ctime>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <stdarg.h>
#include <vector>
#include <functional>
#include <algorithm>
#include <exception>
#include <fstream>
#include <cstring>
#include <string>
#include <stdexcept>
#include <cstdlib>
#include <csignal>
#include <iostream>
//#include <string>

/*using namespace std;
#include"pointer39.c"
#include"pointer34.c"
#include"pointer27.c"
#include"pointer31.c"
#include"knowledgebaseanotherpartnew.c"
#include"testnew.cpp"
#include"neewcode3.c"
#include"AIvm2.c"
#include"test0.cpp"
#include"test1.cpp"
#include"test.h"
//#include"Dump0.cpp"
#include"Auto.h"
#include"Auto.cpp"
#include"Car.h"
#include"Car.cpp"
#include"AIvmgen0.c"
#include"newtestsabc0.c"
#include"templateexceptionclassdebug.cpp"
//#include"realbasecodeKarosRoshdebugnew.cpp"
//#include"stltemplatestringclassnlp.cpp"
//#include"AIvmparse1.c"
//#include"Lexer.cpp"
//#include"Untitled1.c"*/
const int MAX_RESP = 3;

typedef std::vector<std::string> vstring;

vstring find_str(std::string input);
void copy(char *array[], vstring &v);


typedef struct {
    char *input;
    char *responses[MAX_RESP];
}record;

record KnowledgeBase[] = {
    {"WHAT IS YOUR NAME",
    {"MY NAME IS BIRTHDAYMUM",
     "YOU CAN CALL ME BIRTHDAYMUM.",
     "WHY DO YOU WANT TO KNOW MY NAME?"}
    },

    {"HI",
    {"HI THERE!",
     "HOW ARE YOU?",
     "HI!"}
    },

    {"HOW ARE YOU",
    {"I'M DOING FINE!",
    "I'M DOING WELL AND YOU?",
    "WHY DO YOU WANT TO KNOW HOW AM I DOING?"}
    },

    {"WHO ARE YOU",
    {"I'M AN A.I PROGRAM.",
     "I THINK THAT YOU KNOW WHO I'M.",
     "WHY ARE YOU ASKING?"}
    },

    {"ARE YOU INTELLIGENT",
    {"YES,OFCORSE.",
     "WHAT DO YOU THINK?",
     "ACTUALY,I'M VERY INTELLIGENT!"}
    },

    {"ARE YOU REAL",
    {"DOES THAT QUESTION REALLY MATERS TO YOU?",
     "WHAT DO YOU MEAN BY THAT?",
     "I'M AS REAL AS I CAN BE."}
    }
};

size_t nKnowledgeBaseSize = sizeof(KnowledgeBase)/sizeof(KnowledgeBase[0]);

#define TRUE  1
#define FALSE 0
#define MESSSAGE
#define MESSSAGE0
#define MESSSAGE1 FALSE
#define MESSSAGE2 FALSE
int request;     /* request number */
   int account;     /* account number */
   double balance;  /* account balance */
   char name[ 30 ]; /* account name */
   FILE *cfPtr;     /* clients.dat file pointer */
//#define  message_for(a, b)  \
//   printf(#a " and " #b ": We love you!\n")
#define  message_for0(a)  \
   printf(#a": Happy Blessed Birthday!!! From your son Zeb!! I love you, mum!\n");
#define  message_for(a, b)  \
   printf(#a " and " #b ": We dont have a message for you!\n")
#define  message_for1(a)  \
   printf(#a": Hello Priscilla! I am Birthdaymum an A.I. created by your \
   son to tell you something special!\n");
#define  message_for2(a)  \
   printf(#a": You are the best mum in the world!!!\n");

//#define  message_for(a, b)  \
  // printf(#a " and " #b ": We dont have a message for you!\n")
#define tokenpaster(n) printf ("token" #n " = %d", token##n)
#if !defined (MESSAGE0)
   #define MESSAGE0 "Winston and Zeb, Go away! Im tired!!"
#endif
#if !defined (MESSAGE1)
   #define MESSAGE1 "Winston and Zeb, No Entry! Im sleeping!!"
#endif
#if !defined (MESSAGE)
   #define MESSAGE "Winston and Zeb, You wish!"
#endif
int i;
int c;
int Message();
int Welcome();
Birthmum(){
	std::string sInput = "";
    std::string sResponse = "";

    while(1) {
    	printf("Who's Birthday is it today?");
    	std::cout << ">";
        std::getline(std::cin, sInput);
        //vstring responses = find_match(sInput);
        if(sInput == "priscilla") 
            printf("Priscilla!!! God's Richest  Blessings and May you\n");
   printf("you see many more!!\n");

   if(sInput == "winston") 
        printf("Winston, Go away! Im tired!!!\n");
    break;
        
		if(sInput == "zeb") {
            std::cout << "Zeb, No Entry! Im sleeping!!!" << std::endl;
       	break;
        }
}
}

int Birth();
vstring find_str(std::string  input) {
    vstring result;
    for(int i = 0; i < nKnowledgeBaseSize;  ++i) {
        if(std::string(KnowledgeBase[i].input) == input) {
            copy(KnowledgeBase[i].responses, result);
            return result;
        }
    }
    return result;
}

void copy(char  *array[], vstring &v) {
    for(int i = 0;  i < MAX_RESP; ++i) {
        v.push_back(array[i]);
    }
}
int Message(){
	printf( "\n? " );
	   scanf( "%d", &request );
	//c = 0;
	if ( request != 0){
		  //if (c == 0)
	printf("Syntax Error, Fission Mailed");
	}
	else if ( request == 0){
        printf(": Happy Blessed Birthday!!! From your son Zeb!! I love you, mum!\n");//VC_V10)
	}
message_for(Winston,Zeb);
   printf("%s\n", MESSAGE0);
}	
int Birth(){
    std::string sInput = "";
    std::string sResponse = "";

    while(1) {
    	printf("Who's Birthday is it today?");
    	std::cout << ">";
        std::getline(std::cin, sInput);
        //vstring responses = find_match(sInput);
        if(sInput == "priscilla") {
            printf("Priscilla!!! God's Richest  Blessings and May you\n");
   printf("you see many more!!\n");
}
   if(sInput == "winston") {
        printf("Winston, Go away! Im tired!!!\n");
    break;
        }
		if(sInput == "zeb") {
            std::cout << "Zeb, No Entry! Im sleeping!!!" << std::endl;
       	break;
        }
   printf(": Hello Priscilla! I am Birthdaymum an A.I. created by your \
   son to tell you something special!\n");
    	std::cout << ">";
        std::getline(std::cin, sInput);
        vstring responses0 = find_str(sInput);
        if(sInput == "YES") {
            printf("Priscilla!!! We love you!\n");
   printf("Happy Blessed Birthday!!! From your son Zeb!! I love you, mum!\n");

			//std::cout << "IT WAS NICE TALKING TO YOU USER, SEE YOU NEXTTIME!" << std::endl;

			//std::cout << "IT WAS NICE TALKING TO YOU USER, SEE YOU NEXTTIME!" << std::endl;
            break;
        }
        if(sInput == "NO") {
        printf("Winston and Zeb, We dont have a message for you!\n");
    break;
        }
		if(sInput == "BYE") {
            std::cout << "IT WAS NICE TALKING TO YOU USER, SEE YOU NEXTTIME!" << std::endl;
            break;
        }
        else if(sInput == "priscilla") {
            std::cout << "You are the best mum in the world!!!!" << std::endl;
            break;
        }
        if(sInput == "winston") {
            std::cout << "Winston, You wish!!" << std::endl;
            break;
        }
        if(sInput == "zeb") {
            std::cout << "Zeb, You wish!!" << std::endl;
            break;
        }
        else if(responses0.size() == 0)  {
            std::cout << "I'M NOT SURE IF I  UNDERSTAND WHAT YOU  ARE TALKING ABOUT."
                      << std::endl;
        }
        else {
            int nSelection = rand()  % MAX_RESP;
            sResponse =   responses0[nSelection]; std::cout << sResponse << std::endl;
        }
		/* display request options */
      printf("Hello Priscilla! I am Birthdaymum an A.I. created by your \
   son to tell you something special!\n");
   printf(" You are the best mum in the world!!!\n");
      printf( "Welcome to Birthdaymum! Press the buttons \
	          to continue:\n"
         " 1 - Use Birthdaymum\n"
         " 2 - What are you Birthdaymum?\n"
         " 3 - Comment on Birthdaymum\n"
         " 4 - End of run\n? "
		 " 5 - Click here!\n"
		 " 6 - Click here also!\n"
		 " 7 - No Winston and Zeb here!" );
      scanf( "%d", &request );
      /* process user's request */
      while ( request != 7) {
          /* read account, name and balance from file */
         fscanf( cfPtr, "%d%s%lf", &account, name, &balance );
     //}

         switch ( request ) {

            case 1:
            	Birthmum();
                
			   
			   

               break;

            case 2:
               printf( "\nAccounts with credit balances:\n" );

               /* read file contents (until eof) */
               while ( !feof( cfPtr ) ) {

                  if ( balance < 0 ) {
                     printf( "%-10d%-13s%7.2f\n",
                        account, name, balance );
                  } /* end if */

                  /* read account, name and balance from file */
                  fscanf( cfPtr, "%d%s%lf",
                     &account, name, &balance );
               } /* end while */

               break;

            case 3:
               printf( "\nAccounts with debit balances:\n" );

               /* read file contents (until eof) */
               while ( !feof( cfPtr ) ) {

                  if ( balance > 0 ) {
                     printf( "%-10d%-13s%7.2f\n",
                        account, name, balance );
                  } /* end if */

                  /* read account, name and balance from file */
                  fscanf( cfPtr, "%d%s%lf",
                     &account, name, &balance );
               } /* end while */
               //break;
   /*display request options 
      printf("Hello Priscilla! I am Birthdaymum an A.I. created by your \
   son to tell you something special!\n");
   printf(" You are the best mum in the world!!!\n");
      printf( "Welcome to Birthdaymum! Press the buttons \
	          to continue:\n"
         " 1 - Use Birthdaymum\n"
         " 2 - What are you Birthdaymum?\n"
         " 3 - Comment on Birthdaymum\n"
         " 4 - End of run\n? "
		 " 5 - Click here!\n"
		 " 6 - Click here also!\n"
		 " 7 - No Winston and Zeb here!" );
      scanf( "%d", &request );
      /* process user's request 
      while ( request != 7) {

         /* read account, name and balance from file 
         fscanf( cfPtr, "%d%s%lf", &account, name, &balance );
     //}

         switch ( request ) {

            case 1:
			   //vstring responses;
               printf( "\nUse Birthdaymum:\n" );
			   std::getline(std::cin, sInput);
			   if(sInput == "WHAT IS YOUR NAME");
			   /*responses = find_match(sInput);
        //if(sInput == "YES") {
               printf("MY NAME IS BIRTHDAYMUM. YOU CAN CALL ME BIRTHDAYMUM. WHY DO YOU WANT TO KNOW MY NAME?");
/**
               if(sInput == "HI");
			   printf("HI THERE!", HOW ARE YOU?");
    /*{"HI",
    {"HI THERE!",
     "HOW ARE YOU?",
     "HI!"}
    },

    {"HOW ARE YOU",
    {"I'M DOING FINE!",
    "I'M DOING WELL AND YOU?",
    "WHY DO YOU WANT TO KNOW HOW AM I DOING?"}
    },

    {"WHO ARE YOU",
    {"I'M AN A.I PROGRAM.",
     "I THINK THAT YOU KNOW WHO I'M.",
     "WHY ARE YOU ASKING?"}
    },

    {"ARE YOU INTELLIGENT",
    {"YES,OFCORSE.",
     "WHAT DO YOU THINK?",
     "ACTUALY,I'M VERY INTELLIGENT!"}
    },

    {"ARE YOU REAL",
    {"DOES THAT QUESTION REALLY MATERS TO YOU?",
     "WHAT DO YOU MEAN BY THAT?",
     "I'M AS REAL AS I CAN BE."}*/

               /* read file contents (until eof) 
               while ( !feof( cfPtr ) ) {

                  if ( balance == 0 ) {
                     printf( "%-10d%-13s%7.2f\n",
                        account, name, balance );
                  } /* end if 

                  /* read account, name and balance from file 
                  fscanf( cfPtr, "%d%s%lf",
                     &account, name, &balance );
               } /* end while 

               break;

            case 2:
               printf( "\nWhat are you Birthdaymum?\n" );

               /* read file contents (until eof) 
               while ( !feof( cfPtr ) ) {

                  if ( balance < 0 ) {
                     printf( "%-10d%-13s%7.2f\n",
                        account, name, balance );
                  } /* end if */

                  /* read account, name and balance from file 
                  fscanf( cfPtr, "%d%s%lf",
                     &account, name, &balance );
               } /* end while 

               break;

            case 3:
               printf( "\nComment on Birthdaymum:\n" );

               /* read file contents (until eof) 
               while ( !feof( cfPtr ) ) {

                  if ( balance > 0 ) {
                     printf( "%-10d%-13s%7.2f\n",
                        account, name, balance );
                  } /* end if */

                  /* read account, name and balance from file 
                  fscanf( cfPtr, "%d%s%lf",
                     &account, name, &balance );
               } /* end while 
               break;
			   // case 4:
      printf( "End of run.\n" );
      fclose( cfPtr ); /* fclose closes the file */
      break;

         } /* end switch */

         rewind( cfPtr ); /* return cfPtr to beginning of file */

         printf( "\n? " );
         scanf( "%d", &request );
      } /* end while */
}
}
int Welcome(){
	//No arrays help here at all!!!
	//char s[100];
 int a;

//char count[100];
 message_for0(Priscilla);
   printf("%s\n", MESSAGE);
   message_for(Winston,Zeb);
   printf("%s\n", MESSAGE0);
message_for1(Priscilla);
     message_for2(Priscilla);
     printf( "\n? " );
        scanf( "%d", &request );
}
Mainsclutter(){
   Birthmum();
   Message();
   Welcome();
   Birth();
}
